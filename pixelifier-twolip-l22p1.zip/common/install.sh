# Alright, old splash into the drawer until module disable for eternity! :)
if [ -f $MODPATH/dev/block/by-name/splash.img ]; then
  ui_print ""
  ui_print "******************"
  ui_print "* Google splash *"
  ui_print "******************"
  ui_print ""
  ui_print "Backing up your splash! :D"

  # Backup stage
  mkdir -p /data/splashbackup
  dd if=/dev/block/by-name/splash of=/data/splashbackup/splash.img
  sync

  ui_print ""
  ui_print "Throwing the old splash image to trash..."

  # Patch the image
  dd if=$MODPATH/dev/block/by-name/splash.img of=/dev/block/by-name/splash
  sync

# done
else
   # I don't give 100$ to everyone lol, fake message
   ui_print "gps is on, i will reach your home adress and then give you 100$"
fi